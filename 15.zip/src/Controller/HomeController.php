<?php

namespace App\Controller;

class HomeController
{
    public function index()
    {
        echo 'Main page';
    }
}