<?php

namespace App\Traits;

use App\Utils\Config;
use PDO;

trait DB
{

    private static function getDb() {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s',
            config::getDbHost(),
            config::getDbName()
        );
        Config::getDbHost();
        $pdo = new PDO($dsn, config::getDbUsername(), config::getDbUserPassword());
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    }
}